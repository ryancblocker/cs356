#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

vector<char> padData(vector<char> data)
{
    vector<char> paddedData = data;
    int paddingSize = 16 - (data.size() % 16);
    for (int i = 0; i < paddingSize; i++)
    {
        paddedData.push_back(0x81);
    }
    return paddedData;
}

vector<char> unpadData(vector<char> data) {
    while (!data.empty() && data.back() == (char)0x81) {
        data.pop_back();
    }
    return data;
}

vector<char> xorBytes(vector<char> data1, vector<char> data2)
{
    vector<char> result;
    for (int i = 0; i < data1.size(); i++) {
        result.push_back(data1[i] ^ data2[i]);
    }
    return result;
}

vector<char> swapData(vector<char> XOR, vector<char> key) {
    char* start = &XOR[0];
    char* end = &XOR[XOR.size() - 1];

    for(int i = 0; i < key.size(); i++) {
        if (start >= end) {
            break;
        }

        if(key[i] % 2) {
            auto temp = *start;
            *start = *end;
            *end = temp;
        }
        ++start;
        --end;
    }
    return XOR;
}

vector<char> blockCipherEncrypt(vector<char> plaintext, vector<char> key)
{
    vector<char> paddedPlaintext = padData(plaintext);

    if (key.size() < paddedPlaintext.size()) {
    while (key.size() < paddedPlaintext.size()) {
        key.push_back(0x81); // or another padding value
    }
    } else if (key.size() > paddedPlaintext.size()) {
        key.resize(paddedPlaintext.size());
    }


    vector<char> encryptedData = xorBytes(paddedPlaintext, key);
    vector<char> swappedData = swapData(encryptedData, key);
    return swappedData;
}

vector<char> blockCipherDecrypt(vector<char> ciphertext, vector<char> key)
{
    vector<char> swappedData = swapData(ciphertext, key);

    if (key.size() < ciphertext.size()) {
    while (key.size() < ciphertext.size()) {
        key.push_back(0x81); // or another padding value
    }
    } else if (key.size() > ciphertext.size()) {
        key.resize(ciphertext.size());
    }

    vector<char> decryptedData = xorBytes(swappedData, key);
    vector<char> unpaddedData = unpadData(decryptedData);
    return unpaddedData;
}

vector<char> streamCipher(vector<char> data, vector<char> key)
{
    vector<char> result = data;
    for (size_t i = 0; i < data.size(); i++)
    {
        int keyIndex = i % key.size();
        result[i] = data[i] ^ key[keyIndex];
    }
    return result;
}

// Testing Functions!!!!!!!!
void checkXOR(vector<char> key) {
    vector<char> testData = {'T', 'e', 's', 't'};
    vector<char> xorResult = xorBytes(testData, key);
    vector<char> xorTwiceResult = xorBytes(xorResult, key);
    if (testData == xorTwiceResult) {
        cout << "XOR operation is correct" << endl;
    } else {
        cout << "Problem with XOR operation" << endl;
    }
}

void checkSwap(vector<char> key) {
    vector<char> testData = {'T', 'e', 's', 't', 'D', 'a', 't', 'a', 'B', 'l', 'o', 'c', 'k', '1', '6', 'B'};
    vector<char> swappedData = swapData(testData, key);
    vector<char> swapTwiceData = swapData(swappedData, key);
    if (testData == swapTwiceData) {
        cout << "Swap operation is correct" << endl;
    } else {
        cout << "Problem with Swap operation" << endl;
    }
}

void checkPadding() {
    vector<char> testData = {'T', 'e', 's', 't', 'D', 'a', 't', 'a'};
    vector<char> paddedData = padData(testData);
    vector<char> unpaddedData = unpadData(paddedData);
    if (testData == unpaddedData) {
        cout << "Padding functions are correct" << endl;
    } else {
        cout << "Problem with padding/unpadding" << endl;
    }
}

int main(int argc, char *argv[])
{ 

    if (argc != 6)
    {
        cerr << "\nIncorrect Number of Arguments the correct usage is: " << argv[0] << " <B|S> <input_file> <output_file> <key_file> <E|D>\n\n";
        exit(1);
    }

    char cipherType = argv[1][0];
    string inputFile = argv[2];
    string outputFile = argv[3];
    string keyFile = argv[4];
    char action = argv[5][0];

    ifstream keyStream(keyFile, ios::binary);
    if (!keyStream.is_open()) {
        cerr << "\nError opening the key file: " << keyFile << "\n\n";
        exit(1);
    }

    vector<char> key;
    char keyChar;
    while (keyStream.get(keyChar)) {
        key.push_back(keyChar);
    }
    keyStream.close();

    checkXOR(key);
    checkSwap(key);
    checkPadding();

    ifstream inputStream(inputFile, ios::binary);
    if (!inputStream.is_open()) {
        cerr << "\nError opening the input file: " << inputFile << "\n\n";
        exit(1);
    }

    vector<char> inputData;
    while (inputStream.get(keyChar)) {
        inputData.push_back(keyChar);
    }
    inputStream.close();


    vector<char> outputData;

    if (cipherType == 'B')
    {
        if (action == 'E')
        {
            outputData = blockCipherEncrypt(inputData, key);
        } else if (action == 'D')
        {
            outputData = blockCipherDecrypt(inputData, key);
        } else
        {
            cerr << "\nYou must have either 'E' or 'D' (encryption or decryption)" << "\n\n";
            exit(1);
        }
    } 
    else if (cipherType == 'S')
    {
        outputData = streamCipher(inputData, key);
    } 
    else
    {
        cerr << "\nYou must have either 'B' or 'S' (block cipher or stream cipher)" << "\n\n";
        exit(1);
    }

    ofstream outputStream(outputFile, ios::binary);
    if (!outputStream.is_open()) {
        cerr << "\nError opening the output file: " << outputFile << "\n\n";
        exit(1);
    }

    for (char outputChar : outputData) {
        outputStream.put(outputChar);
    }
    outputStream.close();
    return 0;
}



